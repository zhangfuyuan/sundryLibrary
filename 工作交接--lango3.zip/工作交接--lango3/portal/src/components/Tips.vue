<template>
    <div class="tips">
        <el-row>
            <el-col :span="8">
            健康游戏忠告  
            </el-col>
            <el-col :span="8">
            抵制不良游戏
            </el-col>
            <el-col :span="8">
            拒绝盗版游戏
            </el-col>
        </el-row>

        <el-row>
            <el-col :span="8">
            注意自我保护
            </el-col>
            <el-col :span="8">
            谨防受骗上当
            </el-col>
            <el-col :span="8">
            适度游戏益脑
            </el-col>
        </el-row>

        <el-row>
            <el-col :span="8">
            沉迷游戏伤身
            </el-col>
            <el-col :span="8">
            合理安排时间
            </el-col>
            <el-col :span="8">
            享受健康生活
            </el-col>

        </el-row>

    </div>
</template>

<script>
    export default {
        data() {
            return {
            }
        },
    }
</script>

<style scoped>

</style>