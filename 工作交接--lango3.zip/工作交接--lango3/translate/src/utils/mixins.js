export const myMixin = {
  created() {},

  mounted() {},

  destroyed() {},

  methods: {}
}
