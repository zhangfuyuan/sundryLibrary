# my-vue-element

使用 ES2015+、vue、vuex、vue-router 、axios 、element-ui 、vue-i18n 等技术栈常规初始项目架构，之后可执行 `git clone https://github.com/zhangfuyuan/my-vue-element.git` 快速构建新项目

参考：[PanJiaChen/vue-admin-template](https://github.com/PanJiaChen/vue-admin-template)

## 执行命令

```
# clone the project
git clone https://github.com/PanJiaChen/vue-admin-template.git

# enter the project directory
cd vue-admin-template

# install dependency
npm install

# develop
npm run dev

# build for production environment
npm run build:prod
```
