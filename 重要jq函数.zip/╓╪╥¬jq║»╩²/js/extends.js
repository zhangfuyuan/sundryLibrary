/**
 * Created by Administrator on 2017/5/13 0013.
 */

$(function () {
    $.myjq();
});