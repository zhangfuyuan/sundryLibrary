/**
 * Created by Administrator on 2017/5/13 0013.
 */

$.myjq = function(){
    alert('hello,this is my jQuery!');
};

/*改写*/
$.fn.myjq = function(){
    $(this).text('haha,i am coming!');
};



