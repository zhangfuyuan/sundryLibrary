/**
 * Created by Administrator on 2017/5/4 0004.
 */

$(function () {
    var oP = document.getElementById('p1');

    console.log('js中，元素的children属性（即子元素节点数组）长度：' + oP.children.length);
    for(var i=0; i<oP.children.length; i++){
        console.log(oP.children[i]);
    }

    console.log('==============================================================');

    console.log('js中，节点的childNodes属性（即子节点数组）长度：' + oP.childNodes.length);       // * childNodes会获取空格元素作为子节点！
    for(var j=0; j<oP.childNodes.length; j++){
        console.log(oP.childNodes[j]);
    }

    console.log('==============================================================');

    console.log('jq中，元素的children()方法（即子元素节点数组）长度：' + $('#p1').children().length);
    for(var k=0; k<$('#p1').children().length; k++){
        console.log($('#p1').children().eq(k));
    }

    /*
    *   总结：
    *   1、无论在js还是jq，无论是属性还是方法，children获取的都是子元素节点（即html的标签元素）；
    *   2、无论是空格还是空格+文本（甚至纯文本），都被childNodes当作一个子（文本）节点；无论是html标签元素外的文本还是html元素，都被childNodes当作一个子节点；
    *   3、children、childNodes、children()都是数组！
    *
    *   原因：children是Node、Element两者的实例对象；而childNodes只是Node的实例！
    *   所以，所有节点（无论元素或文本节点）都有childNodes属性，而没有子元素的元素节点则没有children属性！
    * */


});