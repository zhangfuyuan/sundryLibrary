/**
 * Created by Administrator on 2017/5/4 0004.
 */

$(function () {

    //jq的remove()方法会移除一个元素节点，无需参数
    $('.jqBtn').click(function () {
        $('.box').children().eq(0).remove();        //jq的children()返回的是一个数组，需要用eq()方法获取元素节点【注意：children()不会获取空格节点】
    });

    //js的removeChild()方法可以移除一个父类的子元素节点，参数必须为childNodes带索引值
    $('.jsBtn').click(function () {
        $('.box').get(0).removeChild(document.getElementsByClassName('box')[0].childNodes[0]);     //childNodes会获取空格元素
    });
});