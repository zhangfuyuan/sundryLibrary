<?php echo json_encode(array("name"=>"John","time"=>"2pm")); ?>



