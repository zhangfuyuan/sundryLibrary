<?php

$_GET['name'] = isset($_GET['name'])?$_GET['name']:'';
$_GET['pasw'] = isset($_GET['pasw'])?$_GET['pasw']:'';

if($_GET['name'] == '13600000000' && $_GET['pasw'] == 'abcd2345'){
	echo '前端5期欢迎你';
}else {
	echo '';
}


?>



