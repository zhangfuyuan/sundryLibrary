<?php

$_POST['name'] = isset($_POST['name'])?$_POST['name']:'';
$_POST['pasw'] = isset($_POST['pasw'])?$_POST['pasw']:'';

if($_POST['name'] == '13600000000' && $_POST['pasw'] == 'abcd2345'){
	echo '前端5期欢迎你';
}else {
	echo '';
}


?>



