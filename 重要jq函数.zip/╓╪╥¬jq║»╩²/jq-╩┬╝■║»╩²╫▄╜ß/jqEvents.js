/**
 * Created by Administrator on 2017/5/3 0003.
 */

$(function () {
    /*
    *      JQ所有事件分类总结
    *      JQ中文网：http://www.jquery123.com/
    * */

    /*  1、浏览器事件*/
    //  1.1 error()：脚本出错事件
    $('#book').error(function() {
        alert('error()：error事件被发送到元素，比如一张图片被引用，由浏览器加载。如果没有正确载入，这个事件就会被调用。');
    }).attr("src", "missing.png");
    //  1.2 resize()：浏览器窗口尺寸改变事件
    $(window).resize(function() {
        alert('resize()：当浏览器window的尺寸改变时，window元素上绑定的resize事件将被触发。');
        $('#p1').text('此时发生改变的窗口尺寸为：'+ $(window).width() +'*'+ $(window).height());
    });
    //  1.3 scroll()：滚条操作事件
    $('#box3').scroll(function() {
        alert('scroll()：当用户在元素内执行了滚动操作，就会在这个元素上触发scroll事件。');
    });


    /*  2、文档加载*/
    //  2.1 load()：全部元素加载完成事件
    $(window).load(function () {
        alert('load()：当所有子元素已经被完全加载完成时，load事件被发送到这个元素。');
    });
    //  2.2 ready()：DOM准备好后执行一个函数
    $(function() {      //即等同于：$(document).ready(function() { });
        alert('ready()：当DOM准备就绪时，指定一个函数来执行。');
    });
    //  2.3 unload()：离开页面触发的事件
    $(window).unload(function() {
        alert('unload()：当用户离开这个页面时，就会触发window元素上的unload事件。');
    });


    /*  3、绑定事件处理器 */
    //  3.1 bind()与unbind()：绑定事件与解绑事件
    $('#box1').bind('mouseover',function () {
        alert('bind()：为一个元素绑定一个事件处理程序。');
    });
    $('#box1').unbind('mouseover');     //注释此句，鼠标悬停在第一个盒子上便会弹出弹框
    //  3.2 delegate()与undelegate()：绑定事件与解绑事件
    var delFun = function () {
        alert('delegate()：为所有匹配选择器的元素绑定一个或多个事件处理函数。');
    };
    $(document.body).delegate('#box1', 'mouseover', delFun);
    $(document.body).undelegate('#box1', 'mouseover', delFun);      //注释此句，鼠标进入第一个盒子上便会弹出弹框
    //  3.3 die()与live()：绑定事件与解绑事件
        //由于不支持链式写法和触发时间漫长等缺点，现不支持使用
    //  3.4 jQuery.proxy()：将元素触发事件跟一个方法、一个参数绑定在一起
    var me = {
        type: "dog",
        test: function(one, two, event) {       //one: you; two: they
            $("#p2")
                .append( "<h3>Hello " + one.type + ":</h3>" )
                .append( "I am a " + this.type + ", " )
                .append( "and they are " + two.type + ".<br>" )
                .append( "Thanks for " + event.type + "ed. " )
        }
    };
    var you = { type: "cat" };
    var they = { type: "fish" };
    var proxy = jQuery.proxy( me.test, me, you, they );     //注意：jQuery.proxy()不能写成$.proxy()
    $("#box4").on( "click", proxy );
    //  3.5 on()与off()：绑定事件与解绑事件
    function myHandler(event) {
        alert(event.data.foo)
    }
    $('#box5').on('click', {foo: 'on()：在选定的元素上绑定一个或多个事件处理函数。'},myHandler);
    //$('#box5').off('click');     //注释此句，鼠标点击在第九个盒子上便不会弹出弹框
    //  3.6 one()：绑定事件，只执行一次
    $("#box6").one("click", function() {
        $(this).css({borderStyle:"inset", cursor:"auto"});
        alert('one()：为元素的事件添加处理函数。处理函数在每个元素上每种事件类型最多执行一次。')
    });
    //  3.7 trigger()与triggerHandler()：绑定事件与绑定事件处理程序
    $("#inp4,#inp5").focus(function(){
        $("<span>Focused!</span>").appendTo($(this).parent()).fadeOut(3000);
    });
    $("#box7>button").click(function(){
        $("#inp4").trigger("focus");
        alert('trigger()：根据绑定到匹配元素的给定的事件类型执行所有的处理程序和行为。');
    });
    $("#box8>button").click(function(){
        $("#inp5").triggerHandler("focus");
        alert('triggerHandler()：为一个事件执行附加到元素的所有处理程序，但不会触发事件的默认行为（例如，表单获焦边框不会高亮）。');
    });


    /*  4、事件对象【注意：此类事件方法的调用时，在事件处理函数中必须加入“event”参数】 */
    //  4.1 event.currentTarget：事件冒泡到哪个对象
    $("#box9").click(function(event) {
        alert($(event.currentTarget).text()); // event.currentTarget相当于this
    });
    $("#box99").click(function(event) {
        alert($(event.currentTarget).text());
    });
    $("#box999").click(function(event) {
        alert($(event.currentTarget).text());
    });
    //  4.2 event.data：绑定了处理程序后，可以给事件传递一个数据（对象）
    $('#box10 button').each(function (i) {
        $(this).on('click',{val: i}, function (event) {
            var msgs = [
                "button = " + ($(this).index()-1),      //button元素前还有一个文本元素
                "event.data.value = " + event.data.val,
                "i = " + i
            ];
            $('#log').text(msgs.join(','));
        });
    });
    //  4.3 event.delegateTarget：绑定了当前正在调用jQuery 事件处理器的元素
    $("#box11").on("click", "button", function(event) {
        $(event.delegateTarget).toggleClass("box11Bgc");
    });
    //  4.4 event.preventDefault()与event.isDefaultPrevented()：默认事件行为将不再触发 || 检测 event.preventDefault() 是否被调用过
    $("#box12 a").eq(1).click(function(event){
        alert( event.isDefaultPrevented() ); // false
        event.preventDefault();
        alert( event.isDefaultPrevented() + ' 调用event.preventDefault()后，百度链接默认事件行为将不再触发');
    });
    //  4.5 event.stopImmediatePropagation()与event.isImmediatePropagationStopped()：阻止剩余的事件处理函数执行并且防止事件冒泡到DOM树上 || 检测 event.stopImmediatePropagation() 是否被调用过。
        //区别：既消除事件冒泡，又解绑了自身同名事件的处理程序，但不会解绑父级元素同名事件的处理程序，只是不触发父级的而已
    $("#box13>p").click(function(event) {
        alert( event.isImmediatePropagationStopped());
        event.stopImmediatePropagation();
        alert( event.isImmediatePropagationStopped() + ' 调用event.stopImmediatePropagation()后，剩下自身的同事件名的处理程序均不执行，同时也不会事件冒泡');
    });
    $("#box13").click(function(event){
        $(this).css("background-color", "#ccc");
    });
    $("#box13>p").click(function(event) {
        $(this).css("background-color", "#ccc");
    });
    //  4.6 event.stopPropagation()与event.isPropagationStopped()：防止事件冒泡到DOM树上，也就是不触发的任何父辈元素上的事件处理函数 || 检测 event.stopPropagation() 是否被调用过
    //区别：只消除了事件冒泡，但不会解绑自身同名事件的处理程序，更不会解绑父级元素同名事件的处理程序，只是不触发父级的而已
    $("#box14>p").click(function(event) {
        alert( event.isPropagationStopped());
        event.stopPropagation();
        alert( event.isPropagationStopped() + ' 调用event.stopPropagation()后，不会事件冒泡,即也不会触发父级元素同名事件的处理程序');
    });
    $("#box14").click(function(event){
        $(this).css("background-color", "#ccc");
    });
    $("#box14>p").click(function(event) {
        $(this).css("background-color", "#ccc");
    });
    //  4.7 event.metaKey、event.namespace：表示事件触发时是否按下Meta键 || 当事件被触发时此属性包含指定的命名空间
        //大多数键盘上并不存在Meta键，该键存在于MIT计算机、Mac计算机或Sun公司的一些计算机键盘上
    $("#box15 p").eq(1).bind("自定义事件名.自定义命名空间", function(event) {
        $(this).text('触发事件所在的命名空间：' + event.namespace);
    });
    $('#box15 button').click(function(e){
        $('#box15 p').eq(0).text('metaKey键是否被按下：' + e.metaKey);
        $('#box15 p').eq(1).trigger('自定义事件名.自定义命名空间');      //“.”一定是英文格式的点号
    });
    //  4.8 event.pageX、event.pageY：鼠标位置坐标（略）
    //  4.9 event.relatedTarget与event.target：在事件中涉及的其它任何DOM元素 || 触发事件的DOM元素
        //即触发事件前后，event.target指向（触发事件的）自身元素，event.relatedTarget指向剩余有关联的元素对象
    $("#box16").mouseout(function(event) {      //离开事件前后：肯定已知前者为此div节点，则event.relatedTarget指向后者
        alert(event.relatedTarget.nodeName);
    });
    $("#box16").mouseover(function(event) {     //悬停事件前后：肯定已知后者为此div节点，则event.relatedTarget指向前者
        alert(event.relatedTarget.nodeName);
    });
    //  4.10 event.result、event.type：自定义事件时，获取返回值 ||  描述事件的性质
    $("#box17 button").click(function(event) {
        return "hey";
    }).click(function(event) {
        $("#box17 p").html( '事件处理返回结果：'+ event.result + '; 触发的事件类型：' + event.type );
    });
    //  4.11 event.timeStamp：这个属性返回事件触发时距离1970年1月1日的毫秒数
    var last, diff;
    $('#box18').click(function(event) {
        if ( last ) {
            diff = event.timeStamp - last;
            $('#box18').append('两次点击事件相隔时间（单位毫秒）： ' + diff + '<br/>');
        } else {
            $('#box18').append('再次点击：<br/>');
        }
        last = event.timeStamp;
    });
    //  4.12 event.which：针对键盘和鼠标事件，这个属性能确定你到底按的是哪个键
        //键盘事件
    $('#box19 input').eq(0).bind('keydown',function(e){
        $('#box19 p').eq(0).html(e.type + ': ' +  e.which );
    });
        //鼠标事件【左击：1；轮击：2；右击：3】
    $('#box19 input').eq(1).bind('mousedown',function(e){
        $('#box19 p').eq(1).html(e.type + ': ' +  e.which );
    });


    /*  5、表单事件 */
    //  5.1 blur()与focus()、focusin()与focusout()：获得焦点与失去焦点事件
        //  5.1.1   blur()与focus()：不支持事件冒泡
    $('#inp1').focus(function () {      //若把focus()事件绑定在“#inp1”的父类元素“#dinp1”，将不会触发自定义的focus()匿名方法
        $('#pinp1').text('focus()：当一个元素获得焦点时，focus事件被触发。');
    });
    $('#inp1').blur(function () {
        $('#pinp1').text('blur()：一个元素失去焦点将触发blur事件（注：此事件不支持冒泡）。');
    });
        //  5.1.2   focusin()与focusout()：支持事件冒泡，可在父类元素检查子类是否获焦
    $('#dinp2').focusin(function () {
        $('#pinp2').text('focusin()：focusin 事件会在元素（或者其内部的任何元素）获得焦点时触发。');
    });
    $('#dinp2').focusout(function () {
        $('#pinp2').text('focusout()：focusout 事件会在元素（或者其内部的任何元素）失去焦点时触发。');
    });
    //  5.2 change()：元素值改变事件
    $('#inp3').change(function () {
        $('#pinp3').text($('#inp3').val());     //对于下拉选择框，复选框和单选按钮，当用户用鼠标作出选择，该事件立即触发，但对于其他类型的input元素，该事件触发将推迟，直到元素失去焦点才会触点。
    });
    //  5.3 select()：文本选择事件
        //此事件只能用在<input type="text"> 和<textarea>。
    $("#box20 input").select( function () {
        alert('select()：当用户在一个元素中进行文本选择时，这个元素上的select事件就会被触发。');
        $("#box20 p").text("文本被改变").show().fadeOut(2000);
    });
    //  5.4 .submit()：表单提交事件
    $("#box21 form").submit(function() {
        if ($("#box21 form input:first").val() == "小明") {
            $("#box21 span").text("提交成功...").show();
            return true;
        }
        $("#box21 span").text("不正确!").show().fadeOut(2000);
        return false;
    });


    /*  6、键盘事件 */
    //  6.1 keydown()：当用户在一个元素上第一次按下键盘上的键的时候，keydown事件就会发送给这个元素（略）
    //  6.2 keypress()：当浏览器捕获一个元素上键盘输入时，keypress就会发送个元素（略）
    //  6.3 keyup()：当用户在一个元素上释放按键的时候，keyup事件就会被附加到这个元素（略）


    /*  7、鼠标事件 */
    //  7.1 click()与dblclick()：鼠标点击事件（单击与双击）
    $('#box1').click(function () {
            alert('click()：一个元素被点击和鼠标按键被按下和释放时候将触发 click 事件。')
    });
    $('#box2').dblclick(function () {
        alert('dblclick()：一个元素被双击时将触发 dblclick 事件。')
    });
    //  7.2 hover()：鼠标进入、离开分别执行
        //绑定两个处理函数
    $("#box22-1 ul li").hover(
        function () {
            $(this).append($("<span> ***</span>"));
        },
        function () {
            $(this).find("span:last").remove();
        }
    );
    $("#box22-1 ul li.fade").hover(function(){$(this).fadeOut(100);$(this).fadeIn(500);});
        //绑定一个处理函数
    $("#box22-2 ul li")
        .filter(":odd")     //:odd 选择器选取每个带有奇数 index 值的元素（比如 1、3、5）
        .hide()
        .end()      //回到最近的一个"破坏性"操作之前。即，将匹配的元素列表变为前一次的状态。（所谓的"破坏性"就是指任何改变所匹配的jQuery元素的操作）
        .filter(":even")        //:even 选择器选取每个带有偶数 index 值的元素（比如 2、4、6）
        .hover(function () {
                $(this).toggleClass("active").next().stop(true, true).slideToggle();        // .stop(是否清空之前整个动画序列,是否将当前动画效果执行到最后)
            });
    //  7.3 mousedown()：当鼠标指针在元素上并按下鼠标键，mousedown事件被发送到这个元素（略）
    //      mouseenter()：该事件在鼠标移入到元素上时被触发（略）
    //      mouseleave()：该事件在鼠标离开元素时被触发【不支持事件冒泡】（略）
    //      mousemove()：当鼠标指针在元素内移动时，mousemove事件就会被触发（略）
    //      mouseout()：当鼠标指针离开元素时，mouseout事件就会被触发【支持事件冒泡】（略）
    //      mouseover()：当鼠标指针进入元素内时，mouseover事件就会被触发（略）
    //      mouseup()：当鼠标指针在元素内，并且鼠标按键被释放时，mouseup事件就会被触发（略）
    //  7.4 toggle()：绑定两个或多个处理程序绑定到匹配的元素，用来执行在交替的点击。
    $("#box23 ul li").toggle(
        function () {
            $(this).css({"list-style-type":"disc", "color":"blue"});
        },
        function () {
            $(this).css({"list-style-type":"disc", "color":"red"});
        },
        function () {
            $(this).css({"list-style-type":"", "color":""});
        }
    );

});