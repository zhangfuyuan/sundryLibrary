window.Page = {
  // 设备编码
  sPadID: '',

  // 请求间隔(秒),默认10
  interval: 10,

  // 当前服务器时间戳(初始显示终端时间)
  systemDateTime: new Date().getTime(),

  // 获取设备编码
  init: function() {
    var uri = this.urlParse();

    if (uri.sPadID) {
      this.sPadID = uri.sPadID;
      this.showToast('获取设备编码成功 : ' + this.sPadID);
    } else {
      this.showToast('获取设备编码失败!');
    }

    if (uri.interval) {
      this.interval = +uri.interval || 10;
    }
  },

  // 获取服务器数据
  getData: function() {
    if (!this.sPadID)
      return;

    var self = this;

    $.ajax({
      type: 'GET', // TODO POST
      url: './data/mock.json?t=' + Date.now(), // TODO http://192.168.6.12:88/SVC/AppointQueueSvc.asmx
      data: {
        sPadID: this.sPadID
      }
    }).done(function(res) {
      if (res.RetCode == '0') {
        // 1.日期时间
        var _date = new Date(res.SystemDateTime);

        if (!isNaN(_date))
          self.systemDateTime = _date.getTime();

        // 2.专科和诊室名称
        $('#deptName').text(res.DeptName);
        $('#roomLabel').text(res.RoomLabel);
        var _roomZoom = $('#doctorBox').width() / $('#doctorRoom').outerWidth();

        if (_roomZoom < 1)
          $('#doctorRoom').css('zoom', _roomZoom);

        // 3.医生照片链接
        res.PhotoUrl && $('#photoUrl').attr('src', res.PhotoUrl.replace('http://yuyueguahao.zsszyy.com.lc:88', 'http://10.0.254.131'));

        // 4.医生姓名和职称
        $('#doctorName').text(res.DoctorName);
        $('#title').text(res.Title);

        // 5.出诊时间
        var _clinicInfo = res.ClinicInfo;
        var _clinicHtml = '';

        if (_clinicInfo) {
          var _clinicInfoList = _clinicInfo.split('$$');

          $.each(_clinicInfoList, function(index, item) {
            var _infos = item.split('##');

            if (_infos[1]) {
              _clinicHtml += '<p>' + _infos[1] + '</p>';
            }
          });
        }

        $('#clinicTime').html(_clinicHtml);

        // 6.呼号和等待的姓名列表
        var _callHtml = '';
        var _awaitHtml = '';
        var _awaitTotal = 0;
        var _patQueue = res.PatQueue;
        var _patQueueLen = _patQueue.length;
        var _awaitShowNum = 8;

        if (_patQueue && _patQueueLen > 0) {
          _patQueue.sort(function(a, b) {
            return a.OrderNo - b.OrderNo;
          });

          $.each(_patQueue, function(index, item) {
            if (index == 0) {
              // 呼号
              _callHtml += '<p><span>' + item.Qno + '</span> <span>' + item.PatName + '</span></p>';
            } else if (0 < index) {
              // 等待
              if (index <= _awaitShowNum) {
                _awaitHtml += '<p class="flex-h-vc"><span class="qno">' + item.Qno +
                  '</span> <span class="pat ' + (item.PatName.length > 3 ? 'marquee' : '') + '">' + item.PatName +
                  '</span></p>';
              }

              _awaitTotal++;
            }
          });
        }

        $('#call').html(_callHtml);
        $('#awaitTotal').text(_awaitTotal);
        $('#awaitList').html(_awaitHtml);
      } else {
        self.showToast('获取数据失败信息 : ' + res.ErrMsg);
      }
    }).fail(function(jqXHR, textStatus, errorThrown) {
      console.log('请求失败 :', textStatus);
      self.showToast('请求失败 : ' + textStatus);
    }).always(function() {
      console.log('请求结束!');
    });
  },

  // 轻提示延时器缓存
  showToastTimer: null,

  // 显示轻提示
  showToast(msg) {
    // if (this.showToastTimer) {
    //   clearTimeout(this.showToastTimer);
    //   this.showToastTimer = null;
    // }

    // $('#toast').text(msg).removeClass('hide');
    // this.showToastTimer = setTimeout(function() {
    //   $('#toast').addClass('hide');
    // }, 2500);
  },

  // 补零
  padLeftZero: function(str) {
    var _str = str + '';

    return ('00' + _str).substr(_str.length);
  },

  /**
   * G_UTILS.HTTP.urlParse
   * 解析 URL 参数
   * http://localhost:8080/?id=123&key=vaule#/restaurant/seller -> {id: "123", key: "vaule"}
   * 
   * @param  {String} url 路径字符串
   * @return {Object} 键值对对象
   */
  urlParse: function(url) {
    // window.location.href 当前文件的绝对地址
    // window.location.search 当前文件的哈希地址
    var obj = {};
    var reg = /[?&][^?&]+=[^?&#\/]+/g;
    var arr = (url || window.location.search || window.location.href).match(reg); // ["?id=123", "&key=vaule"]

    if (arr) {
      arr.forEach(function(item) {
        // 删除 ? 和 &，以 = 为标志分割数组
        var tempArr = item.substring(1).split('='); // ["id", "123"]  ["key", "vaule"]
        // 使用 decodeURIComponent() 对编码后的 URI 进行解码
        var key = decodeURIComponent(tempArr[0]);
        var value = decodeURIComponent(tempArr[1]);
        obj[key] = value;
      })
    }

    return obj;
  },

  // 更新显示时间
  updateDateTime: function() {
    var _date = new Date(this.systemDateTime);

    if (!isNaN(_date)) {
      var _Y = _date.getFullYear() + '年';
      var _M = this.padLeftZero(_date.getMonth() + 1) + '月';
      var _D = this.padLeftZero(_date.getDate()) + '日';
      var _d = '星期' + ['日', '一', '二', '三', '四', '五', '六'][_date.getDay()];
      var _h = this.padLeftZero(_date.getHours()) + ':';
      var _m = this.padLeftZero(_date.getMinutes()) + ':';
      var _s = this.padLeftZero(_date.getSeconds());

      $('#ymd').text(_Y + _M + _D);
      $('#day').text(_d);
      $('#time').text(_h + _m + _s);
    }

    this.systemDateTime += 1000;
  }
}

Page.init();
Page.updateDateTime();
Page.getData();
setInterval(Page.getData.bind(Page), Page.interval * 1000);
setInterval(Page.updateDateTime.bind(Page), 1000);
