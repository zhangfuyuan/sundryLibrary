window.Page = {
  // 设备编码
  sPadID: '',

  // 请求间隔(秒),默认10
  interval: 10,

  // 当前服务器时间戳(初始显示终端时间)
  systemDateTime: new Date().getTime(),

  // 初始化页面数据
  init: function() {
    var uri = this.urlParse();

    if (uri.sPadID) {
      this.sPadID = uri.sPadID;
      this.showToast('获取设备编码成功 : ' + this.sPadID);
    } else {
      this.showToast('获取设备编码失败!');
    }

    if (uri.interval) {
      this.interval = +uri.interval || 10;
    }

    this.updateDateTime();
    this.getData();
  },

  // 获取服务器数据
  getData: function() {
    if (!this.sPadID)
      return;

    var self = this;

    $.ajax({
      type: 'POST', // TODO GET
      url: '/apm-web/f/common/queryAppointQueue', // TODO './data/mock.json?t=' + Date.now(),
      data: {
        sPadID: this.sPadID
      }
    }).done(function(res) {
      if (res && res.RetCode == '0') {
        // 1.日期时间
        try {
          var _date = new Date(res.SystemDateTime && (res.SystemDateTime + '') || '');

          if (!isNaN(_date))
            self.systemDateTime = _date.getTime();
        } catch (err) {
          console.log(err);
          self.showToast('更新 日期时间 异常');
        }

        // 2.诊室名称和专科
        var _roomLabel = res.RoomLabel && (res.RoomLabel + '') || '';
        var _deptName = res.DeptName && (res.DeptName + '') || '';

        try {
          $('#roomLabel').text(_roomLabel)[_roomLabel.length > 8 ? 'addClass' : 'removeClass']('marquee');
          $('#deptName').text(_deptName)[_deptName.length > 10 ? 'addClass' : 'removeClass']('marquee');
        } catch (err) {
          console.log(err);
          self.showToast('更新 诊室名称和专科 异常');
        }

        // 3.医生照片链接
        var _photoUrl = res.PhotoUrl && (res.PhotoUrl + '') || '';

        try {
          $('#photoUrl').attr('src', _photoUrl && _photoUrl.length > 0 ? _photoUrl.replace(
            'http://yuyueguahao.zsszyy.com.lc:88', 'http://10.0.254.131').replace(
            'http://192.168.2.35', 'http://10.0.254.131') : './img/doctor.jpg?t=1');
        } catch (err) {
          console.log(err);
          self.showToast('更新 医生照片 异常');
        }

        // 4.医生姓名和职称
        var _doctorName = res.DoctorName && (res.DoctorName + '') || '';
        var _doctorTitle = res.Title && (res.Title + '') || '';

        try {
          $('#doctorName').text(_doctorName)[_doctorName.length > 4 ? 'addClass' : 'removeClass']('marquee');
          $('#doctorTitle').text(_doctorTitle)[_doctorTitle.length > 5 ? 'addClass' : 'removeClass']('marquee');
        } catch (err) {
          console.log(err);
          self.showToast('更新 医生姓名和职称 异常');
        }

        // 5.出诊时间
        var _clinicInfo = res.ClinicInfo && (res.ClinicInfo + '') || '';
        var _clinicHtml = '';

        try {
          if (_clinicInfo && typeof(_clinicInfo.split) === 'function') {
            var _clinicInfoList = _clinicInfo.split('$$');
            var _clinicInfoListLen = 0;

            $.each(_clinicInfoList, function(index, item) {
              if (item && item.length > 0) {
                var _infos = item.split('##');

                _clinicInfoListLen++;
                _clinicHtml += '<div class="clinic-time-box">' +
                  '<p>' +
                  '<span class="clinic-time-order">' + _clinicInfoListLen + '</span> ' +
                  '<span class="clinic-time-clinic">' + (_infos[3] || '--') + '</span> ' +
                  '<span>' + (_infos[0] || '--') + '</span>' +
                  '</p>' +
                  '<p>' + (_infos[2] || '--') + '</p>' +
                  '<p>' + (_infos[1] || '--') + '</p>' +
                  '</div>';
              }
            });
          }

          $('#clinicTime').html(_clinicHtml)[$('#clinicTime').height() > $('#clinicTime').parent().height() ?
            'addClass' : 'removeClass']('marquee-clinic');
        } catch (err) {
          console.log(err);
          self.showToast('更新 出诊时间 异常');
        }

        // 6.呼号和等待的姓名列表
        var _callHtml = '';
        var _awaitHtml = '';
        var _awaitTotal = 0;
        var _patQueue = res.PatQueue;
        var _patQueueLen = _patQueue.length;
        var _awaitShowNum = 8;

        try {
          if (_patQueue && _patQueueLen > 0) {
            _patQueue.sort(function(a, b) {
              return a.OrderNo - b.OrderNo;
            });

            $.each(_patQueue, function(index, item) {
              if (index == 0) {
                // 呼号
                _callHtml += '<p><span>' + item.Qno + '</span> &nbsp;&nbsp; <span>' + item.PatName +
                  '</span></p>';
              } else if (0 < index) {
                // 等待
                if (index <= _awaitShowNum) {
                  _awaitHtml += '<p class="flex-h-vc">' +
                    '<span class="order">' + index + '</span>' +
                    '<span class="pat-marquee-wrap">' +
                    '<span class="' + (item.Qno.length + item.PatName.length > 6 ? 'pat-marquee' : '') +
                    '">' +
                    item.Qno + '&nbsp;&nbsp;' + item.PatName +
                    '</span>' +
                    '</span>' +
                    '</p>';
                }

                _awaitTotal++;
              }
            });
          }
        } catch (err) {
          console.log(err);
          self.showToast('更新 候诊列表 异常');
        }

        $('#call').html(_callHtml);
        $('#awaitTotal').text(_awaitTotal);
        $('#awaitList').html(_awaitHtml);
      } else {
        self.showToast('获取数据失败信息 : ' + res.ErrMsg);
      }
    }).fail(function(jqXHR, textStatus, errorThrown) {
      self.showToast('请求失败 : ' + textStatus);
    });
  },

  // 轻提示延时器缓存
  showToastTimer: null,

  // 显示轻提示
  showToast(msg) {
    if (this.showToastTimer) {
      clearTimeout(this.showToastTimer);
      this.showToastTimer = null;
    }

    $('#toast').text(msg).removeClass('hide');
    this.showToastTimer = setTimeout(function() {
      $('#toast').addClass('hide');
    }, 2500);
  },

  // 补零
  padLeftZero: function(str) {
    var _str = str + '';

    return ('00' + _str).substr(_str.length);
  },

  // 解析 URL 参数
  urlParse: function(url) {
    // window.location.href 当前文件的绝对地址
    // window.location.search 当前文件的哈希地址
    var obj = {};
    var reg = /[?&][^?&]+=[^?&#\/]+/g;
    var arr = (url || window.location.search || window.location.href).match(reg); // ["?id=123", "&key=vaule"]

    if (arr) {
      arr.forEach(function(item) {
        // 删除 ? 和 &，以 = 为标志分割数组
        var tempArr = item.substring(1).split('='); // ["id", "123"]  ["key", "vaule"]
        // 使用 decodeURIComponent() 对编码后的 URI 进行解码
        var key = decodeURIComponent(tempArr[0]);
        var value = decodeURIComponent(tempArr[1]);
        obj[key] = value;
      })
    }

    return obj;
  },

  // 更新显示时间
  updateDateTime: function() {
    var _date = new Date(this.systemDateTime);

    if (!isNaN(_date)) {
      var _Y = _date.getFullYear() + '年';
      var _M = this.padLeftZero(_date.getMonth() + 1) + '月';
      var _D = this.padLeftZero(_date.getDate()) + '日';
      var _d = '星期' + ['日', '一', '二', '三', '四', '五', '六'][_date.getDay()];
      var _h = this.padLeftZero(_date.getHours()) + ':';
      var _m = this.padLeftZero(_date.getMinutes()) + ':';
      var _s = this.padLeftZero(_date.getSeconds());

      $('#ymd').text(_Y + _M + _D);
      $('#day').text(_d);
      $('#time').text(_h + _m + _s);
    }

    this.systemDateTime += 1000;
  }
}

Page.init();
setInterval(Page.updateDateTime.bind(Page), 1000);
setInterval(Page.getData.bind(Page), Page.interval * 1000);
