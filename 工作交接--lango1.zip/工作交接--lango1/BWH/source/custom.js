$(function(){
	try{
		initCustomWidget();
	}catch(e){
		
	}
	
});
//跳转到自定义控件页面
function initCustomWidget(){
	var custom = $("[id^=custom]");
	custom.each(function(){
		var $_form = $("form[target='"+$(this).attr("id")+"']");
		var inPer = window.application&&window.application.getTerminalnameAndlocation&&window.application.getTerminalnameAndlocation() || JSON.stringify({"organization": "organization", "location": "location", "schoolName": "schoolName", "class_validkey": "class_validkey", "schoolId": "schoolId", "terminalName": "terminalName"});
		inPer = jQuery.parseJSON(inPer);
		/*var classId = inPer.organization;
		var classRoomId = inPer.location;*/
		var classId = inPer.organization;
		var classRoomId = inPer.location;
		var schoolName=inPer.schoolName;
		var class_validkey = inPer.class_validkey;
		var schoolId = inPer.schoolId;
		var terminalName = inPer.terminalName;
		$_form.find("#classId").val(classId);
		$_form.find("#classRoomId").val(classRoomId);
		if(schoolName){
			$_form.find("#schoolName").val(schoolName);
		}
		if(schoolId){
			$_form.find("#schoolId").val(schoolId);
		}
		if(class_validkey){
			$_form.find("#class_validkey").val(class_validkey);
		}		
		if(terminalName){
			$_form.find("#terminalName").val(terminalName);
			
			// 中福医院排队叫号项目专用
			if($_form.find("#sPadID").length>0 && !$_form.find("#sPadID").val()){
				$_form.find("#sPadID").val(terminalName);
			}
		}
		$_form.submit();
	})
}